//
//  ViewController.h
//  coreData
//
//  Created by Dinesh Jaganathan on 09/10/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
@interface ViewController : UIViewController

{
    AppDelegate *appd;
}
@property(nonatomic,retain)NSManagedObjectContext *managedObjectContext;
@end

