//
//  ViewController.m
//  coreData
//
//  Created by Dinesh Jaganathan on 09/10/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import "ViewController.h"
#import "Student.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    appd=(AppDelegate *) [[UIApplication sharedApplication]delegate];
    self.managedObjectContext = [appd managedObjectContext];
    
    Student *std = [NSEntityDescription insertNewObjectForEntityForName:@"Student" inManagedObjectContext:self.managedObjectContext];
    std.name = @"Test";
    std.rollno  = [NSNumber numberWithInteger:1000];
    std.batch = @"1 std";
    NSError *err;
    
    if([self.managedObjectContext save:&err] )
    {
        NSLog(@"Saved successfully");
    }
    else
    {
        NSLog(@"Problem with saving ");

    }
    
    NSFetchRequest *fetch = [[NSFetchRequest alloc]initWithEntityName:@"Student"];
    
    NSArray *getArray  = [self.managedObjectContext executeFetchRequest:fetch error:&err];
    NSLog(@"%@",getArray);
    
    NSLog(@"%@",[getArray valueForKey:@"name"]);

    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
