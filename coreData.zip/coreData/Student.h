//
//  Student.h
//  coreData
//
//  Created by Dinesh Jaganathan on 09/10/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface Student : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "Student+CoreDataProperties.h"
