//
//  Student.m
//  coreData
//
//  Created by Dinesh Jaganathan on 09/10/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import "Student.h"

@implementation Student

// Insert code here to add functionality to your managed object subclass

@end
