//
//  Student+CoreDataProperties.m
//  coreData
//
//  Created by Dinesh Jaganathan on 09/10/16.
//  Copyright © 2016 Greens. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Student+CoreDataProperties.h"

@implementation Student (CoreDataProperties)

@dynamic name;
@dynamic rollno;
@dynamic batch;

@end
