//
//  Student+CoreDataProperties.h
//  coreData
//
//  Created by Dinesh Jaganathan on 09/10/16.
//  Copyright © 2016 Greens. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Student.h"

NS_ASSUME_NONNULL_BEGIN

@interface Student (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *name;
@property (nullable, nonatomic, retain) NSNumber *rollno;
@property (nullable, nonatomic, retain) NSString *batch;

@end

NS_ASSUME_NONNULL_END
